
from django.conf.urls import url, include
from django.contrib import admin

print 'something'
urlpatterns = [
    url(r'^$', include('apps.first_app.urls')),
    url(r'^admin/', admin.site.urls),
]
